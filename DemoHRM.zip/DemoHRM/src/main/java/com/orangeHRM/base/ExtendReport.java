package com.orangeHRM.base;

import org.openqa.selenium.WebDriver;

public class ExtendReport {
         public WebDriver driver;
           
       
         
}
